from django.shortcuts import render, redirect
from django.http import JsonResponse
from .forms import RegistroUsuarioForm, LoginForm
from .models import VerificationCode, Usuario
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
import re
import random

# --- Función auxiliar para generar códigos de verificación ---
def generar_codigo():
    return random.randint(100000, 999999)

# --- Vista para el login simple ---
def login_simple(request):
    return render(request, 'users/login.html', {'form': LoginForm()})

# --- Vista para registro de usuarios con verificación de teléfono ---
def registro(request):
    if request.method == 'POST':
        phone_number = request.POST.get('phone')
        if phone_number:
            # Generar y guardar el código de verificación
            codigo = generar_codigo()
            VerificationCode.objects.create(phone_number=phone_number, code=str(codigo))
            
            # Simular envío de SMS (esto debería conectarse a un servicio real de SMS)
            print(f'Código enviado a {phone_number}: {codigo}')
            
            # Guardar el número de teléfono en la sesión
            request.session['phone_number'] = phone_number

            # Redirigir a la pantalla de verificar código
            return redirect('verificar_codigo')
    return render(request, 'users/register.html')

# --- Vista para formulario de registro de usuarios ---
def register_form(request):
    if request.method == 'POST':
        form = RegistroUsuarioForm(request.POST)
        if form.is_valid():
            usuario = form.save(commit=False)

            # Validación adicional del nombre de usuario
            if not usuario.username:
                messages.error(request, 'El nombre de usuario es obligatorio.')
                return render(request, 'users/register_form.html', {'form': form})
            
            usuario.save()
            messages.success(request, 'Registro completado con éxito. Por favor, inicia sesión.')
            return redirect('emparejar:emp_opciones')  # Redirigir a emp_opciones
        else:
            messages.error(request, 'Por favor, corrige los errores del formulario.')
    else:
        form = RegistroUsuarioForm()

    return render(request, 'users/register_form.html', {'form': form})

# --- Vista para login ---
def login_view(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            identifier = form.cleaned_data.get('identifier')
            password = form.cleaned_data.get('password')

            # Verificar si es un número de teléfono
            if re.match(r'^\+?[0-9\s]{10,20}$', identifier):
                try:
                    user_obj = Usuario.objects.get(telefono=identifier)
                    user = authenticate(request, username=user_obj.username, password=password)
                except Usuario.DoesNotExist:
                    user = None
            # Verificar si es un correo electrónico
            elif '@' in identifier:
                user = authenticate(request, username=identifier, password=password)
            else:
                user = None

            if user:
                login(request, user)
                return redirect('emparejar:emp_opciones') # Redirigir a emp_opciones
            else:
                messages.error(request, 'Credenciales inválidas. Por favor, verifica tu usuario/teléfono y contraseña.')
        else:
            messages.error(request, 'El formulario contiene errores.')
    else:
        form = LoginForm()

    return render(request, 'users/login.html', {'form': form})

