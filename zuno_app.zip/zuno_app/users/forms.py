from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import Usuario

class RegistroUsuarioForm(UserCreationForm):
    username = forms.CharField(
        max_length=150,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Nombre de usuario'}),
        required=True,
        help_text="El nombre de usuario debe ser único y no puede contener espacios ni caracteres especiales."
    )
    nombre_completo = forms.CharField(
        max_length=150,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Nombre completo'})
    )
    genero = forms.ChoiceField(
        choices=Usuario.GENERO_CHOICES,
        widget=forms.Select(attrs={'class': 'form-select'})
    )
    fecha_nacimiento = forms.DateField(
        widget=forms.DateInput(attrs={'class': 'form-control', 'type': 'date'})
    )
    intereses = forms.MultipleChoiceField(
        choices=[
            ('salida_parejas', 'Salida en parejas'),
            ('salida_familia', 'Salida en familia'),
            ('salida_amigos', 'Salida con amigos'),
            ('restaurantes', 'Restaurantes'),
            ('servicios', 'Servicios'),
            ('diversion', 'Diversión'),
        ],
        widget=forms.CheckboxSelectMultiple(attrs={'class': 'form-check'})
    )
    telefono = forms.CharField(
        max_length=15,
        required=True,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Número de teléfono'})
    )

    password1 = forms.CharField(
        label='Contraseña',
        widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Contraseña'}),
        help_text="Tu contraseña debe contener al menos 8 caracteres y no ser común."
    )
    password2 = forms.CharField(
        label='Confirmar Contraseña',
        widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Confirmar contraseña'}),
        help_text="Por favor, ingresa la misma contraseña para verificación."
    )

    class Meta:
        model = Usuario
        fields = [
            'username',  # Asegúrate de que el campo esté aquí
            'nombre_completo',
            'genero',
            'fecha_nacimiento',
            'telefono',
            'password1',
            'password2',
            'intereses',
        ]

    def clean_username(self):
        username = self.cleaned_data.get('username')
        if Usuario.objects.filter(username=username).exists():
            raise forms.ValidationError("Este nombre de usuario ya está en uso.")
        return username


class LoginForm(forms.Form):
    identifier = forms.CharField(
        max_length=150,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Correo electrónico o teléfono'}),
        label='Correo electrónico o teléfono'
    )
    password = forms.CharField(
        widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Contraseña'}),
        label='Contraseña'
    )