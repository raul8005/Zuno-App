from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import CodigoEmparejamiento
from django.db.models import Q


@login_required
def generar_codigo(request):
    """Genera un código único si no existe uno activo para el usuario."""
    codigo_existente = CodigoEmparejamiento.objects.filter(usuario1=request.user, usuario2__isnull=True).first()
    if codigo_existente:
        messages.info(request, f"Ya tienes un código activo: {codigo_existente.codigo_pareja}")
    else:
        nuevo_codigo = CodigoEmparejamiento(usuario1=request.user)
        nuevo_codigo.save()
        messages.success(request, f"Código generado exitosamente: {nuevo_codigo.codigo_pareja}")
    return redirect('emparejar:emp_opciones')


@login_required
def emp_opciones(request):
    """Muestra las opciones de emparejamiento solo si el usuario no está emparejado."""
    # Verificar si el usuario ya está emparejado
    pareja = CodigoEmparejamiento.objects.filter(
        Q(usuario1=request.user) | Q(usuario2=request.user), usuario2__isnull=False
    ).first()

    # Si ya está emparejado, redirigir a la gestión financiera
    if pareja:
        return redirect('gestionfinanza:gestion_finanzas')

    # Verificar si el usuario tiene un código sin emparejar
    codigo_pareja = CodigoEmparejamiento.objects.filter(usuario1=request.user, usuario2__isnull=True).first()

    if request.method == 'POST':
        if 'generar_codigo' in request.POST:
            # Si no tiene un código activo, genera uno nuevo
            if not codigo_pareja:
                nuevo_codigo = CodigoEmparejamiento(usuario1=request.user)
                nuevo_codigo.save()
                messages.success(request, f"Código generado correctamente: {nuevo_codigo.codigo_pareja}")
            else:
                messages.info(request, f"Ya tienes un código activo: {codigo_pareja.codigo_pareja}")
            return redirect('emparejar:emp_opciones')

        if 'conectar_pareja' in request.POST:
            # Procesar la conexión con un código ingresado
            codigo_ingresado = request.POST.get('codigo')
            try:
                codigo = CodigoEmparejamiento.objects.get(codigo_pareja=codigo_ingresado, usuario2__isnull=True)
                if codigo.usuario1 != request.user:
                    codigo.usuario2 = request.user
                    codigo.save()
                    messages.success(request, "Te has emparejado exitosamente.")
                    return redirect('gestionfinanza:gestion_finanzas')
                else:
                    messages.error(request, "No puedes emparejarte contigo mismo.")
            except CodigoEmparejamiento.DoesNotExist:
                messages.error(request, "Código inválido o ya utilizado.")

    return render(request, 'emparejar/emp_opciones.html', {'codigo_pareja': codigo_pareja})



