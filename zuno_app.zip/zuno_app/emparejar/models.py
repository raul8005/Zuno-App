from django.db import models
from django.conf import settings
import random
import string

class CodigoEmparejamiento(models.Model):
    usuario1 = models.ForeignKey(settings.AUTH_USER_MODEL, related_name="usuario1", on_delete=models.CASCADE)
    usuario2 = models.ForeignKey(settings.AUTH_USER_MODEL, related_name="usuario2", on_delete=models.CASCADE, null=True, blank=True)
    codigo_pareja = models.CharField(max_length=6, unique=True)  # Código de 6 caracteres alfanuméricos
    fecha_emparejamiento = models.DateTimeField(auto_now_add=True)
    saldo_inicial = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    saldo_disponible = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    def __str__(self):
        return f"{self.usuario1.username} & {self.usuario2.username if self.usuario2 else 'Pendiente'}"

    @staticmethod
    def generar_codigo_unico():
        """
        Genera un código único que no exista en la base de datos.
        """
        while True:
            codigo = ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))
            if not CodigoEmparejamiento.objects.filter(codigo_pareja=codigo).exists():
                return codigo

    def save(self, *args, **kwargs):
        if not self.codigo_pareja:  # Si el código no ha sido generado aún
            self.codigo_pareja = self.generar_codigo_unico()
        super().save(*args, **kwargs)
