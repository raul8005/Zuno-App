from firebase_admin import firestore, credentials, initialize_app
import os
from pathlib import Path

print("Inicio del script de prueba")  # Mensaje de depuración

# Inicializa Firebase si no está ya inicializado
try:
    BASE_DIR = Path(__file__).resolve().parent
    FIREBASE_CREDENTIALS = os.path.join(BASE_DIR, 'config/zuno-34f3b-firebase-adminsdk-pcuag-f04699bcf5.json')

    print("Inicializando Firebase...")  # Mensaje de depuración
    import firebase_admin
    if not firebase_admin._apps:
        cred = credentials.Certificate(FIREBASE_CREDENTIALS)
        initialize_app(cred)
    print("Firebase inicializado correctamente.")
except Exception as e:
    print("Error al inicializar Firebase:", e)

def test_firebase_connection():
    print("Intentando conectar a Firestore...")  # Mensaje de depuración
    try:
        db = firestore.client()  # Conexión a Firestore
        print("Conexión a Firestore exitosa:", db)
    except Exception as e:
        print("Error al conectar a Firestore:", e)

if __name__ == "__main__":
    print("Ejecutando la función de prueba...")
    test_firebase_connection()
