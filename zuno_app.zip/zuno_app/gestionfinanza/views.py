from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.core.exceptions import ObjectDoesNotExist
from django.contrib import messages
from .models import Gasto, Pareja, Saldo
from emparejar.models import CodigoEmparejamiento
from .forms import GastoForm, SaldoInicialForm
from django.contrib.auth import get_user_model
from django.http import Http404
from django.http import JsonResponse
from datetime import date
from decimal import Decimal
User = get_user_model()  # Asegura compatibilidad con modelo de usuario personalizado

@login_required
def chatbot(request):
    return render(request, 'gestionfinanza/chatbot.html')

# --------------------------------------------------------------------------------------
from django.db.models import Sum
from django.db.models.functions import TruncDate
from collections import defaultdict

@login_required
def gestion_finanzas(request):
    # Obtener la pareja del usuario logueado
    pareja = CodigoEmparejamiento.objects.filter(
        Q(usuario1=request.user) | Q(usuario2=request.user)
    ).first()

    if not pareja:
        messages.error(request, "Debes estar emparejado para acceder a esta sección.")
        return redirect('emparejar:emp_opciones')

    # Configuración de categorías
    categoria_config = {
        'Alimentos': {'color': '#4A90E2', 'icono': 'utensils'},
        'Transporte': {'color': '#FF6B6B', 'icono': 'plane'},
        'Entretenimiento': {'color': '#FFD93D', 'icono': 'face-smile'},
        'Ropa': {'color': '#95D5B2', 'icono': 'shirt'},
        'Vivienda': {'color': '#8A2BE2', 'icono': 'house'},
        'Salud': {'color': '#FF8C42', 'icono': 'heart'},
        'Educación': {'color': '#4ECDC4', 'icono': 'book'},
        'Otros': {'color': '#B8B8B8', 'icono': 'bars'}
    }

    # Obtener los últimos 15 gastos relacionados con la pareja
    gastos = Gasto.objects.filter(
        pareja=pareja
    ).order_by('-fecha')[:10]

    # Agrupar los gastos por fecha
    gastos_por_fecha = defaultdict(list)
    totales_por_fecha = defaultdict(Decimal)

    for gasto in gastos:
        fecha = gasto.fecha
        gastos_por_fecha[fecha].append({
            'categoria': gasto.categoria,
            'descripcion': gasto.descripcion,
            'monto': gasto.monto,
            'config': categoria_config.get(gasto.categoria, categoria_config['Otros'])
        })
        totales_por_fecha[fecha] += gasto.monto

    # Convertir los gastos agrupados en una lista ordenada por fecha
    gastos_agrupados = [
        {
            'fecha': fecha,
            'gastos': gastos_por_fecha[fecha],
            'total': totales_por_fecha[fecha]
        }
        for fecha in sorted(gastos_por_fecha.keys(), reverse=True)
    ][:5]  # Limitamos a los últimos 5 días con gastos

    # Calcular el saldo disponible
    saldo_disponible = pareja.saldo_inicial - sum(totales_por_fecha.values())

    # Pasar la información al contexto
    context = {
        'pareja': pareja,
        'saldo_disponible': saldo_disponible,
        'gastos_agrupados': gastos_agrupados,
        'categoria_config': categoria_config
    }

    return render(request, 'gestionfinanza/gestionfinanzas.html', context)
# --------------------------------------------------------------------------------------
@login_required
def obtener_gastos_recientes(request):
    # Obtener los 5 gastos más recientes del usuario
    gastos = Gasto.objects.filter(usuario=request.user).order_by('-fecha')[:5]
    
    # Preparar los datos para enviar como JSON, ahora incluyendo el nombre del usuario
    gastos_data = [{
        "descripcion": gasto.descripcion,
        "monto": gasto.monto,
        "fecha": gasto.fecha.strftime("%d/%m/%Y"),  # Formato de fecha
        "categoria": gasto.categoria,
        "usuario": gasto.usuario.username,  # Incluimos el nombre del usuario que hizo el gasto
    } for gasto in gastos]
    
    return JsonResponse(gastos_data, safe=False)
# --------------------------------------------------------------------------------------
@login_required
def agregar_saldo(request):
    if request.method == 'POST':
        try:
            monto = Decimal(request.POST.get('monto', 0))
            pareja = CodigoEmparejamiento.objects.filter(
                Q(usuario1=request.user) | Q(usuario2=request.user)
            ).first()
            
            if pareja:
                pareja.saldo_inicial += monto
                pareja.save()
                return JsonResponse({'success': True, 'nuevo_saldo': float(pareja.saldo_inicial)})
            
        except (ValueError, Decimal.InvalidOperation):
            pass
            
    return JsonResponse({'success': False}, status=400)
# --------------------------------------------------------------------------------------
@login_required
def registrar_gasto(request):
    # Obtener la pareja del usuario actual
    pareja = CodigoEmparejamiento.objects.filter(
        Q(usuario1=request.user) | Q(usuario2=request.user)
    ).first()

    if not pareja or not pareja.usuario2:
        messages.error(request, "Debes estar emparejado para registrar gastos.")
        return redirect('emparejar:emp_opciones')

    if request.method == "POST":
        descripcion = request.POST.get('descripcion')
        monto = request.POST.get('monto')
        categoria = request.POST.get('categoria')
        responsable_pago = request.POST.get('responsable_pago')  # "A", "B" o "D"
        # Validar que el monto sea válido
        try:
            monto = float(monto)
            if monto <= 0:
                raise ValueError
        except (ValueError, TypeError):
            messages.error(request, "El monto debe ser un número mayor a cero.")
            return redirect('gestionfinanza:registrar_gasto')

        # Registrar el gasto
        Gasto.objects.create(
            descripcion=descripcion,
            monto=monto,
            categoria=categoria,
            pareja=pareja,
            tipo_gasto=responsable_pago,  # "A", "B" o "D"
            fecha=date.today()
        )
        messages.success(request, "Gasto registrado correctamente.")
        return redirect('gestionfinanza:gestion_finanzas')

    context = {
        'usuario1': pareja.usuario1.username,
        'usuario2': pareja.usuario2.username,
    }
    return render(request, 'gestionfinanza/registrar_gasto.html', context)
# --------------------------------------------------------------------------------------
@login_required
def dashboard(request):
    saldo = Saldo.objects.filter(usuario=request.user).first()
    gastos = Gasto.objects.filter(usuario=request.user).order_by('-fecha')[:5]
    return render(request, 'dashboard.html', {'saldo': saldo, 'gastos': gastos})
# --------------------------------------------------------------------------------------

from django.utils.timezone import now
from datetime import timedelta

def gastos_totales(request):
    hoy = datetime.now()
    inicio_semana = hoy - timedelta(days=hoy.weekday())  # Lunes de esta semana
    inicio_mes = hoy.replace(day=1)  # Primer día del mes

    # Filtrar gastos según el periodo
    gastos_recientes = Gasto.objects.filter(fecha__gte=hoy.replace(hour=0, minute=0, second=0, microsecond=0), 
                                           fecha__lte=hoy.replace(hour=23, minute=59, second=59, microsecond=999999))
    gastos_semanales = Gasto.objects.filter(fecha__gte=inicio_semana)
    gastos_mensuales = Gasto.objects.filter(fecha__gte=inicio_mes)

    context = {
        'gastos_recientes': gastos_recientes,
        'gastos_semanales': gastos_semanales,
        'gastos_mensuales': gastos_mensuales,
    }
    return render(request, 'gestionfinanza/gastostotales.html', context)

# --------------------------------------------------------------------------------------
from django.db.models import Sum
@login_required
def balance_gastos(request):
    # Obtener los gastos del usuario
    gastos = Gasto.objects.filter(usuario=request.user)

    # Calcular el total de gastos
    total_gastos = sum(gasto.monto for gasto in gastos)

    # Obtener el saldo disponible
    saldo = Saldo.objects.filter(usuario=request.user).first()
    saldo_disponible = saldo.saldo_disponible if saldo else 0

    # Calcular el dinero restante (saldo disponible - total gastos)
    dinero_restante = saldo_disponible - total_gastos

    # Obtener los gastos por categoría
    categorias = ['Alimentos', 'Transporte', 'Ropa', 'Vivienda', 'Entretenimiento', 'Salud', 'Educación', 'Otros']
    gastos_por_categoria = {categoria: 0 for categoria in categorias}

    for gasto in gastos:
        if gasto.categoria in gastos_por_categoria:
            gastos_por_categoria[gasto.categoria] += gasto.monto

    # Calcular los porcentajes para el gráfico de categorías
    total_gastos_categoria = sum(gastos_por_categoria.values())
    if total_gastos_categoria > 0:
        porcentajes = {categoria: (monto / total_gastos_categoria) * 100 for categoria, monto in gastos_por_categoria.items()}
    else:
        porcentajes = {categoria: 0 for categoria in gastos_por_categoria}

    # Pasar los datos a la plantilla
    context = {
        'total_ingresos': saldo_disponible,
        'total_gastos': total_gastos,
        'saldo_disponible': saldo_disponible,
        'dinero_restante': dinero_restante,
        'gastos_por_categoria': gastos_por_categoria,
        'porcentajes': porcentajes,
    }

    return render(request, 'gestionfinanza/balancegastos.html', context)
# --------------------------------------------------------------------------------------

# ------------------- Balance de gastos -------------------

from django.db.models import   Sum, Avg, Count
from django.utils import timezone
from datetime import datetime

from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from django.contrib import messages
from django.db.models import Count, Sum
from datetime import datetime
from django.db.models import Q
import calendar
import numpy as np

@login_required
def balance_gastos(request):
    pareja = CodigoEmparejamiento.objects.filter(
        Q(usuario1=request.user) | Q(usuario2=request.user)
    ).first()

    if not pareja or not pareja.usuario2:
        messages.error(request, "Debes estar emparejado para acceder a esta sección.")
        return redirect('emparejar:emp_opciones')

    # Configuración de fechas
    fecha_fin = datetime.now()
    fecha_inicio = fecha_fin.replace(day=1)
    
    # Fechas del mes anterior
    fecha_fin_anterior = fecha_inicio - timedelta(days=1)
    fecha_inicio_anterior = fecha_fin_anterior.replace(day=1)

    # Configuración de categorías con sus colores e iconos
    categoria_config = {
        'Alimentos': {'color': '#4A90E2', 'icono': 'utensils'},
        'Transporte': {'color': '#FF6B6B', 'icono': 'plane'},
        'Entretenimiento': {'color': '#FFD93D', 'icono': 'face-smile'},
        'Ropa': {'color': '#95D5B2', 'icono': 'shirt'},
        'Vivienda': {'color': '#8A2BE2', 'icono': 'house'},
        'Salud': {'color': '#FF8C42', 'icono': 'heart'},
        'Educación': {'color': '#4ECDC4', 'icono': 'book'},
        'Otros': {'color': '#B8B8B8', 'icono': 'bars'}
    }

    # Obtener gastos del mes actual
    gastos_mes_actual = Gasto.objects.filter(
        pareja=pareja,
        fecha__range=(fecha_inicio, fecha_fin)
    )

    # Obtener gastos del mes anterior
    gastos_mes_anterior = Gasto.objects.filter(
        pareja=pareja,
        fecha__range=(fecha_inicio_anterior, fecha_fin_anterior)
    )

    # Calcular totales del mes actual
    gastos_por_categoria = gastos_mes_actual.values('categoria').annotate(
        total=Sum('monto'),
        transacciones=Count('id')
    ).order_by('-total')

    total_gastos = gastos_mes_actual.aggregate(total=Sum('monto'))['total'] or 0
    total_gastos_anterior = gastos_mes_anterior.aggregate(total=Sum('monto'))['total'] or 0

    # Calcular saldo disponible
    saldo_disponible = pareja.saldo_inicial - total_gastos
    saldo_disponible_anterior = pareja.saldo_inicial - total_gastos_anterior

    # Calcular variaciones porcentuales
    def calcular_variacion(actual, anterior):
        if anterior == 0:
            return 0 if actual == 0 else 100
        return ((actual - anterior) / anterior) * 100

    variacion_gastos = calcular_variacion(float(total_gastos), float(total_gastos_anterior))
    variacion_saldo = calcular_variacion(float(saldo_disponible), float(saldo_disponible_anterior))

    # Preparar datos para la plantilla
    categorias = []
    for gasto in gastos_por_categoria:
        categoria = gasto['categoria']
        config = categoria_config.get(categoria, {
            'color': '#B8B8B8',
            'icono': 'bars'
        })
        
        categorias.append({
            'nombre': categoria,
            'total': float(gasto['total']),
            'transacciones': gasto['transacciones'],
            'porcentaje': float(round((gasto['total'] / total_gastos * 100) if total_gastos > 0 else 0, 1)),
            'color': config['color'],
            'icono': config['icono']
        })

    context = {
        'pareja': pareja.usuario2 if pareja.usuario1 == request.user else pareja.usuario1,
        'saldo_inicial': float(pareja.saldo_inicial),
        'saldo_disponible': float(saldo_disponible),
        'total_gastos': float(total_gastos),
        'variacion_gastos': round(variacion_gastos, 1),
        'variacion_saldo': round(variacion_saldo, 1),
        'categorias': categorias,
        'fecha_inicio': fecha_inicio.strftime('%Y-%m-%d'),
        'fecha_fin': fecha_fin.strftime('%Y-%m-%d'),
    }

    return render(request, 'gestionfinanza/balancegastos.html', context)


def generar_sugerencia(categoria, proyeccion, promedio_historico, promedio_transacciones):
    if categoria == 'Alimentación':
        if proyeccion > promedio_historico * 1.2:
            return "Reduce un 10% (Ahorras $%.2f)" % (proyeccion * 0.1)
        return "Mantén tu presupuesto actual"
    
    elif categoria == 'Transporte':
        if proyeccion > 300:
            return "Usa transporte público"
        return "Buen manejo del presupuesto"
    
    elif categoria == 'Entretenimiento':
        if promedio_transacciones > 8:
            return "Limita salidas a 2/mes"
        return "Presupuesto razonable"
    
    elif categoria == 'Vivienda':
        return "Gasto fijo necesario"
    
    return "Revisa si hay oportunidades de ahorro"

@login_required
def proyeccion_mensual(request):
    categoria_config = {
        'Alimentos': {'color': '#4A90E2', 'icono': 'utensils'},
        'Transporte': {'color': '#FF6B6B', 'icono': 'plane'},
        'Entretenimiento': {'color': '#FFD93D', 'icono': 'face-smile'},
        'Ropa': {'color': '#95D5B2', 'icono': 'shirt'},
        'Vivienda': {'color': '#8A2BE2', 'icono': 'house'},
        'Salud': {'color': '#FF8C42', 'icono': 'heart'},
        'Educación': {'color': '#4ECDC4', 'icono': 'book'},
        'Otros': {'color': '#B8B8B8', 'icono': 'bars'}
    }

    pareja = CodigoEmparejamiento.objects.filter(
        usuario1=request.user
    ).first() or CodigoEmparejamiento.objects.filter(
        usuario2=request.user
    ).first()

    if not pareja:
        messages.error(request, "Debes estar emparejado para acceder a esta sección.")
        return redirect('emparejar:emp_opciones')

    # Obtener fecha actual y mes siguiente
    fecha_actual = datetime.now()
    primer_dia_mes_actual = fecha_actual.replace(day=1)
    ultimo_dia_mes_actual = fecha_actual.replace(
        day=calendar.monthrange(fecha_actual.year, fecha_actual.month)[1]
    )
    
    # Obtener gastos de los últimos 6 meses por categoría
    gastos_historicos = Gasto.objects.filter(
        pareja=pareja,
        fecha__gte=fecha_actual - timedelta(days=180)
    ).values('categoria').annotate(
        total_mes=Sum('monto'),
        num_transacciones=Count('id'),
        promedio_transaccion=Avg('monto')
    )

    # Algoritmo de proyección mejorado
    proyecciones = []
    for gasto in gastos_historicos:
        # Base: promedio mensual
        base_proyeccion = float(gasto['total_mes'] / 6)
        
        # Factor de tendencia (últimos 3 meses vs 3 meses anteriores)
        gastos_recientes = Gasto.objects.filter(
            pareja=pareja,
            categoria=gasto['categoria'],
            fecha__gte=fecha_actual - timedelta(days=90)
        ).aggregate(total=Sum('monto'))['total'] or 0

        gastos_anteriores = Gasto.objects.filter(
            pareja=pareja,
            categoria=gasto['categoria'],
            fecha__lt=fecha_actual - timedelta(days=90),
            fecha__gte=fecha_actual - timedelta(days=180)
        ).aggregate(total=Sum('monto'))['total'] or 0

        factor_tendencia = 1.0
        if gastos_anteriores > 0:
            factor_tendencia = float(gastos_recientes) / float(gastos_anteriores)
            factor_tendencia = min(max(factor_tendencia, 0.7), 1.3)  # Limitar el factor

        # Factor estacional (comparar con el mismo mes del año anterior)
        mes_siguiente = (fecha_actual.month % 12) + 1
        gastos_mismo_mes = Gasto.objects.filter(
            pareja=pareja,
            categoria=gasto['categoria'],
            fecha__month=mes_siguiente
        ).aggregate(total=Sum('monto'))['total'] or 0

        factor_estacional = 1.0
        if gastos_mismo_mes > 0:
            factor_estacional = float(gastos_mismo_mes) / base_proyeccion
            factor_estacional = min(max(factor_estacional, 0.8), 1.2)

        # Proyección final
        proyeccion = base_proyeccion * factor_tendencia * factor_estacional

        # Generar sugerencia basada en el análisis
        sugerencia = generar_sugerencia(
            gasto['categoria'], 
            proyeccion, 
            base_proyeccion,
            gasto['num_transacciones'] / 6  # promedio mensual de transacciones
        )

        proyecciones.append({
            'categoria': gasto['categoria'],
            'proyeccion': round(proyeccion, 2),
            'sugerencia': sugerencia,
            'color': categoria_config.get(gasto['categoria'], categoria_config['Otros'])['color'],
            'icono': categoria_config.get(gasto['categoria'], categoria_config['Otros'])['icono']
        })

    # Ordenar proyecciones por monto
    proyecciones.sort(key=lambda x: x['proyeccion'], reverse=True)

    # Datos para el gráfico
    meses_proyeccion = 12
    datos_grafico = []
    saldo_actual = float(pareja.saldo_inicial)
    
    for i in range(meses_proyeccion):
        mes = (fecha_actual.month + i) % 12 + 1
        año = fecha_actual.year + ((fecha_actual.month + i) // 12)
        
        total_gastos_mes = sum(p['proyeccion'] for p in proyecciones)
        saldo_proyectado = max(0, saldo_actual - total_gastos_mes)
        
        datos_grafico.append({
            'mes': calendar.month_abbr[mes],
            'año': año,
            'gastos': total_gastos_mes,
            'saldo': saldo_proyectado
        })
        
        saldo_actual = saldo_proyectado

    context = {
        'proyecciones': proyecciones,
        'datos_grafico': datos_grafico,
        'fecha_inicio': primer_dia_mes_actual.strftime('%d %b %Y'),
        'fecha_fin': ultimo_dia_mes_actual.strftime('%d %b %Y'),
    }

    return render(request, 'gestionfinanza/proyeccion_mensual.html', context)



