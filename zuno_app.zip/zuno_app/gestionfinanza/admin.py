from django.contrib import admin
from .models import Gasto
# Register your models here.
admin.site.register(Gasto)