from django.conf import settings
from django.db import models
from django.contrib.auth.models import AbstractUser
from emparejar.models import CodigoEmparejamiento


# Unificar las categorías para los movimientos financieros
CATEGORIAS = [
    ('Alimentos', 'Alimentos'),
    ('Transporte', 'Transporte'),
    ('Ropa', 'Ropa'),
    ('Vivienda', 'Vivienda'),
    ('Entretenimiento', 'Entretenimiento'),
    ('Salud', 'Salud'),
    ('Educación', 'Educación'),
    ('Otros', 'Otros'),
]

class Usuario(AbstractUser):
    # Añadir 'related_name' para evitar conflictos
    groups = models.ManyToManyField(
        'auth.Group',
        related_name='usuarios_groups',  # Nuevo nombre para evitar conflicto
        blank=True
    )
    user_permissions = models.ManyToManyField(
        'auth.Permission',
        related_name='usuarios_permissions',  # Nuevo nombre para evitar conflicto
        blank=True
    )

    def __str__(self):
        return self.username


class Pareja(models.Model):
    usuario1 = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='usuario1_pareja')
    usuario2 = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='usuario2_pareja')

    saldo_disponible = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    # Añadir 'related_name' para evitar conflictos
    groups = models.ManyToManyField(
        'auth.Group',
        related_name='parejas_groups',  # Nuevo nombre para evitar conflicto
        blank=True
    )
    user_permissions = models.ManyToManyField(
        'auth.Permission',
        related_name='parejas_permissions',  # Nuevo nombre para evitar conflicto
        blank=True
    )

    def __str__(self):
        return f"Pareja: {self.usuario1.username} y {self.usuario2.username}"

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=['usuario1', 'usuario2'], name='unique_pareja')
        ]


class Saldo(models.Model):
    usuario = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='saldo')
    saldo_disponible = models.DecimalField(max_digits=10, decimal_places=2, default=0)


from django.db import models
from django.contrib.auth.models import User

class Gasto(models.Model):
    # Definir las opciones para el tipo de gasto
    TIPO_GASTO_CHOICES = [
        ('A', 'Usuario A'),      # Gasto hecho por el primer usuario de la pareja
        ('B', 'Usuario B'),      # Gasto hecho por el segundo usuario de la pareja
        ('D', 'Dividido'),       # Gasto compartido entre ambos usuarios
    ]

    descripcion = models.CharField(max_length=200)
    monto = models.DecimalField(max_digits=10, decimal_places=2)
    fecha = models.DateField(null=True, blank=True)  # Ahora fecha es opcional
    categoria = models.CharField(max_length=100)
    pareja = models.ForeignKey(
        CodigoEmparejamiento,
        on_delete=models.CASCADE,
        related_name="gastos",  # Relación entre pareja y sus gastos
        null=True,  # Permitir nulos temporalmente
        blank=True
    )
    tipo_gasto = models.CharField(
        max_length=1,
        choices=TIPO_GASTO_CHOICES,
        default='A',  # Por defecto, asignado al primer usuario de la pareja
    )

    def calcular_monto_usuario(self, usuario):
        """
        Devuelve cuánto del gasto corresponde a un usuario específico dentro de la pareja.
        """
        if self.tipo_gasto == 'A' and usuario == self.pareja.usuario1:
            return self.monto  # Todo el gasto pertenece a Usuario A
        elif self.tipo_gasto == 'B' and usuario == self.pareja.usuario2:
            return self.monto  # Todo el gasto pertenece a Usuario B
        elif self.tipo_gasto == 'D':  # Dividido
            return self.monto / 2  # Dividir el monto entre ambos usuarios
        return 0  # Si el usuario no pertenece a la pareja o no se asigna

    def __str__(self):
        tipo = self.get_tipo_gasto_display()
        return f"{self.descripcion} - {self.monto} ({tipo})"
