from django import forms
from .models import Gasto
from django.contrib.auth.models import User

class SaldoInicialForm(forms.Form):
    saldo_inicial = forms.DecimalField(
        max_digits=10, 
        decimal_places=2, 
        label="Saldo Inicial", 
        required=True
    )
    
class GastoForm(forms.ModelForm):
    class Meta:
        model = Gasto
        fields = ['pareja', 'tipo_gasto', 'categoria', 'descripcion', 'monto']  # Incluir 'pareja' y 'tipo_gasto'

    def __init__(self, *args, **kwargs):
        pareja = kwargs.pop('pareja', None)  # Obtener la pareja del argumento kwargs
        super().__init__(*args, **kwargs)

        # Filtrar opciones del campo 'tipo_gasto' si se pasa una pareja
        if pareja:
            self.fields['pareja'].queryset = pareja
            self.fields['tipo_gasto'].choices = [
                ('A', f"{pareja.usuario1.username}"),  # Usuario 1
                ('B', f"{pareja.usuario2.username}"),  # Usuario 2
                ('D', 'Dividido')  # Gasto compartido
            ]