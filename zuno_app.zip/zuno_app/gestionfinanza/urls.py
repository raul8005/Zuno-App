from django.urls import path, include
from . import views

app_name = 'gestionfinanza'

urlpatterns = [
    #path('', views.gestion_finanzas, name='gestion_finanzas'),
    path('agregar_saldo/', views.agregar_saldo, name='agregar_saldo'),
    path('registrar_gasto/', views.registrar_gasto, name='registrar_gasto'),  
    path('gastos_totales/', views.gastos_totales, name='gastos_totales'),
    path('balance_gastos/', views.balance_gastos, name='balance_gastos'),
    path('proyeccion_mensual/', views.proyeccion_mensual, name='proyeccion_mensual'),
    path('gestionfinanzas/', views.gestion_finanzas, name='gestion_finanzas'),
    path('obtener_gastos_recientes/', views.obtener_gastos_recientes, name='obtener_gastos_recientes'),
    path('chatbot/', views.chatbot, name='chatbot'),
]
