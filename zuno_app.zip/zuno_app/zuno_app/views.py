from django.shortcuts import render, redirect
from users.forms import RegistroUsuarioForm  # Asegúrate de tener el formulario correcto en forms.py
from django.contrib.auth import login
from django.contrib.auth import logout
# Vista para el home
def home(request):
    return render(request, 'home.html')

# Vista para el registro de usuario
def registro(request):
    if request.method == 'POST':
        form = RegistroUsuarioForm(request.POST)
        if form.is_valid():
            user = form.save()  # Guarda el usuario
            login(request, user)  # Inicia sesión automáticamente al registrar
            return redirect('login')  # Redirige a la página de login después del registro
    else:
        form = RegistroUsuarioForm()
    return render(request, 'registro.html', {'form': form})
