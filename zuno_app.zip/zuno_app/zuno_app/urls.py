from django.contrib import admin
from django.urls import path, include
from . import views  # vista de inicio

urlpatterns = [
    path('', views.home, name='home'),  
    path('admin/', admin.site.urls),
    path('users/', include('users.urls')),  
    path('gestionfinanza/', include('gestionfinanza.urls')), 
    path('emparejar/', include('emparejar.urls')), 
    path('gestionfinanza/', include('gestionfinanza.urls')),
    path('configuracion/', include('configuracion.urls')),
    path('registro/', views.registro, name='registro'),  #  vista de registro
    path('gestionfinanza/', include('gestionfinanza.urls')),
    path('users/', include('users.urls')), 
]
